import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // Als je het TMS op een submap wil draaien (bv. jouwdomein.nl/tms/)
  // zet dan base: '/tms/'
  // Voor root van het domein (jouwdomein.nl) laat je dit staan:
  base: '/',
  build: {
    outDir: 'dist',
    sourcemap: false,
  }
})
