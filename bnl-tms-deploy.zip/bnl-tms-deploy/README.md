# BNL Shipping TMS – Deployment Guide

## Stap 1 — Zet GitHub repository op

1. Ga naar [github.com](https://github.com) en maak een gratis account (als je dat nog niet hebt)
2. Klik op **New repository** (groene knop rechtsboven)
3. Naam: `bnl-tms`
4. Zet op **Private** (zodat je code niet publiek is)
5. Klik **Create repository**

## Stap 2 — Upload de bestanden

### Optie A: Via GitHub website (makkelijkst)
1. In je nieuwe repository, klik **uploading an existing file**
2. Sleep alle bestanden uit deze map naar het uploadvenster:
   - `package.json`
   - `vite.config.js`
   - `index.html`
   - `.gitignore`
   - Map `src/` (inclusief `main.jsx` en `App.jsx`)
   - Map `public/` (inclusief `_redirects`, `.htaccess`, `favicon.svg`)
   - Map `.github/` (inclusief `workflows/deploy.yml`)
3. **Belangrijk:** `src/App.jsx` = jouw `bnlshipping-tms.jsx` bestand (hernoem het)
4. Klik **Commit changes**

### Optie B: Via terminal (voor gevorderden)
```bash
git clone https://github.com/JOUW-NAAM/bnl-tms.git
# Kopieer alle bestanden naar de map
# Hernoem bnlshipping-tms.jsx naar src/App.jsx
git add .
git commit -m "Initial TMS deployment"
git push
```

## Stap 3 — Cloudflare Pages instellen

1. Ga naar [pages.cloudflare.com](https://pages.cloudflare.com) – maak gratis account
2. Klik **Create a project** → **Connect to Git**
3. Koppel je GitHub account en selecteer `bnl-tms`
4. Vul in:
   - **Framework preset:** `Vite`
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
5. Klik **Save and Deploy**

→ Je krijgt direct een URL zoals `bnl-tms.pages.dev`

## Stap 4 — Automatisch deployen koppelen (GitHub Actions)

1. In Cloudflare: **My Profile** → **API Tokens** → **Create Token**
   - Gebruik template: **Edit Cloudflare Workers**
   - Klik **Create Token** – kopieer de token
2. Je **Account ID** staat rechts op de Cloudflare dashboard homepage
3. Ga naar GitHub → je repository → **Settings** → **Secrets and variables** → **Actions**
4. Voeg toe:
   - `CLOUDFLARE_API_TOKEN` → jouw API token
   - `CLOUDFLARE_ACCOUNT_ID` → jouw account ID

Vanaf nu: elke keer dat je een bestand aanpast en naar GitHub pusht → automatisch live! ✅

## Stap 5 — Eigen domein koppelen (one.com → Cloudflare)

### In Cloudflare Pages:
1. Ga naar jouw Pages project → **Custom domains**
2. Klik **Set up a custom domain**
3. Vul in: `tms.jouwdomein.nl` (of `jouwdomein.nl` voor de root)

### In one.com:
1. Log in → **Domeinen** → jouw domein → **DNS-instellingen**
2. Voeg een **CNAME record** toe:
   - **Naam:** `tms`
   - **Waarde:** `bnl-tms.pages.dev`
   - **TTL:** 3600
3. Klik **Opslaan**

Na 10-30 minuten is `tms.jouwdomein.nl` live! 🚀

---

## Samenvatting workflow

```
Jij past App.jsx aan
       ↓
Push naar GitHub (of bestand uploaden)
       ↓
GitHub Actions bouwt automatisch (npm run build)
       ↓
Cloudflare Pages deployt dist/ naar CDN
       ↓
tms.jouwdomein.nl is bijgewerkt (< 2 minuten)
```

## Kosten

| Service | Kosten |
|---------|--------|
| GitHub | Gratis (private repo) |
| Cloudflare Pages | Gratis (500 builds/maand) |
| one.com domein | Wat je al betaalt |
| **Totaal** | **€0 extra** |
